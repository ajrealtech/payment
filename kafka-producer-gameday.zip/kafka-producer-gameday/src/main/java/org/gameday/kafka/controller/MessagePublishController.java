package org.gameday.kafka.controller;

import java.util.List;

import org.gameday.kafka.dto.OrderConfirm;
import org.gameday.kafka.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessagePublishController {
	
	  @Autowired
	 private   OrderService productService;
	 
	  /*
	   * name	-  	  Product Name
	   * location -   Delivery location
	   * store-id  -  store in which product is scanned
	   */
	  @GetMapping("/publish")
	  public String publsihProduct() {
		  
		  OrderConfirm p = new OrderConfirm();
			p.setUsername("Hey there");
			return productService.findProduct(p);
		} 
	  
	@PostMapping("/order")
	public String allProduct(@RequestBody OrderConfirm product) {
		///Product p = new Product();
		//p.setName(name);
		return productService.findProduct(product);
	}
}
